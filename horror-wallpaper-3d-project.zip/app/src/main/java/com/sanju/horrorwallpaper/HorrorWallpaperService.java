package com.sanju.horrorwallpaper;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;
import android.os.Handler;
import android.os.Looper;
import java.util.Random;

public class HorrorWallpaperService extends WallpaperService {
    @Override
    public Engine onCreateEngine() {
        return new HorrorEngine();
    }

    private class HorrorEngine extends Engine {
        private final Handler handler = new Handler(Looper.getMainLooper());
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Random random = new Random(7);
        private boolean visible;
        private float phase = 0f;
        private final Runnable drawRunner = new Runnable() {
            @Override public void run() {
                drawFrame();
            }
        };

        HorrorEngine() {
            setTouchEventsEnabled(false);
        }

        @Override
        public void onVisibilityChanged(boolean isVisible) {
            visible = isVisible;
            if (visible) drawFrame(); else handler.removeCallbacks(drawRunner);
        }

        @Override
        public void onSurfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            super.onSurfaceChanged(holder, format, width, height);
            drawFrame();
        }

        @Override
        public void onSurfaceDestroyed(SurfaceHolder holder) {
            visible = false;
            handler.removeCallbacks(drawRunner);
            super.onSurfaceDestroyed(holder);
        }

        @Override
        public void onDestroy() {
            visible = false;
            handler.removeCallbacks(drawRunner);
            super.onDestroy();
        }

        private void drawFrame() {
            SurfaceHolder holder = getSurfaceHolder();
            Canvas canvas = null;
            try {
                canvas = holder.lockCanvas();
                if (canvas != null) render(canvas);
            } catch (Exception ignored) {
            } finally {
                if (canvas != null) holder.unlockCanvasAndPost(canvas);
            }
            handler.removeCallbacks(drawRunner);
            if (visible) handler.postDelayed(drawRunner, 40);
        }

        private void render(Canvas c) {
            int w = c.getWidth(), h = c.getHeight();
            c.drawColor(0xFF05090B);

            // Dim moon glow
            paint.setShader(new RadialGradient(w * 0.72f, h * 0.26f, w * 0.42f,
                    new int[]{0x553D5960, 0x22202F34, 0x0005090B},
                    null, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, paint);
            paint.setShader(null);

            // Distant haunted silhouettes
            paint.setColor(0xFF090F11);
            c.drawRect(0, h * 0.70f, w, h, paint);
            for (int i = 0; i < 7; i++) {
                float x = i * w / 6f;
                float peak = h * (0.48f + (i % 3) * 0.045f);
                paint.setColor(0xFF070C0E);
                c.drawCircle(x, peak, w * 0.11f, paint);
                c.drawRect(x - w * 0.11f, peak, x + w * 0.11f, h, paint);
            }

            // Slowly drifting fog bands
            for (int i = 0; i < 5; i++) {
                float y = h * (0.58f + i * 0.075f);
                float x = (float)Math.sin(phase * 0.55f + i * 1.7f) * w * 0.12f;
                paint.setShader(new RadialGradient(w * 0.5f + x, y, w * 0.62f,
                        new int[]{0x223C5558, 0x1230474A, 0x0005090B},
                        null, Shader.TileMode.CLAMP));
                c.drawRect(0, y - h * 0.12f, w, y + h * 0.12f, paint);
                paint.setShader(null);
            }

            // Two eerie glowing eyes in the darkness
            float eyeY = h * 0.56f + (float)Math.sin(phase) * h * 0.006f;
            float eyeX = w * 0.5f;
            int glow = (int)(95 + 45 * (0.5 + 0.5 * Math.sin(phase * 1.8f)));
            paint.setShader(new RadialGradient(eyeX, eyeY, w * 0.13f,
                    new int[]{(glow << 24) | 0x00FF2424, 0x00FF2020},
                    null, Shader.TileMode.CLAMP));
            c.drawCircle(eyeX, eyeY, w * 0.13f, paint);
            paint.setShader(null);
            paint.setColor(0xFFFF3535);
            c.drawOval(eyeX - w * 0.075f, eyeY - h * 0.009f,
                    eyeX - w * 0.035f, eyeY + h * 0.009f, paint);
            c.drawOval(eyeX + w * 0.035f, eyeY - h * 0.009f,
                    eyeX + w * 0.075f, eyeY + h * 0.009f, paint);

            // Subtle vignette
            paint.setShader(new RadialGradient(w / 2f, h / 2f, Math.max(w, h) * 0.72f,
                    new int[]{0x00000000, 0xAA000000},
                    null, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, paint);
            paint.setShader(null);

            phase += 0.035f;
        }
    }
}
