# Horror Wallpaper 3D

A starter Android live wallpaper app. The first build contains a lightweight animated horror scene with drifting fog and glowing eyes.

## Build
GitHub Actions runs `gradle assembleDebug` and uploads the APK as an artifact.

## Install and apply
Install the debug APK, open the app, tap **PREVIEW & APPLY LIVE WALLPAPER**, then choose **Set wallpaper**.

This is an animated 2D/2.5D starter, not a full real-time 3D renderer. Future versions can add layered artwork, parallax, and OpenGL rendering.
